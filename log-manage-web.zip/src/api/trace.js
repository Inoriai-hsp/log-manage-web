import request from '@/utils/request'

export function listOpLog(params) {
    return request({
        url: '/block-manager/opLog/logs',
        method: 'get',
        params: params
    })
}