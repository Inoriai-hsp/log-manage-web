<template>
  <div class="app-container">
    <el-card class="operate-container" shadow="never">
      <i class="el-icon-tickets" style="margin-top: 5px"></i>
      <span style="margin-top: 5px">日志列表</span>
      <el-button
        class="btn-add"
        @click="handleAddLog()"
        size="mini">
        添加
      </el-button>
    </el-card>
    <div class="table-container">
      <el-table ref="logListTable"
                style="width: 100%"
                :data="list"
                v-loading="listLoading" border>
        <el-table-column label="日志ID" align="center" prop="id">
          <!-- <template slot-scope="scope">{{scope.row.id}}</template> -->
        </el-table-column>
        <el-table-column label="数字摘要" align="center" prop="hash">
          <!-- <template slot-scope="scope">{{scope.row.hash}}</template> -->
        </el-table-column>
        <el-table-column label="上传时间" align="center">
          <template slot-scope="scope">{{scope.row.createTime}}</template>
        </el-table-column>
        <el-table-column label="日志类型" align="center" :formatter="typeFormat">
          <!-- <template slot-scope="scope">{{scope.row.type }}</template> -->
        </el-table-column>
        <el-table-column label="操作" align="center">
          <template slot-scope="scope">
            <el-button
              size="mini"
              type="primary"
              @click="handleDetail(scope.$index, scope.row)">查看详情
            </el-button>
            <el-button
              size="mini"
              type="success"
              @click="handleCheck(scope.$index, scope.row)">一致性校验
            </el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <div class="pagination-container">
      <el-pagination
        background
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
        layout="total, sizes,prev, pager, next,jumper"
        :page-size="listQuery.size"
        :page-sizes="[5,10,15]"
        :current-page.sync="listQuery.current"
        :total="total">
      </el-pagination>
    </div>
    <el-dialog
      title="日志详情"
      :visible.sync="dialogVisible"
      width="40%">
      <el-card>
      <el-row>
        <el-col :span="12"><div>
          <div>日志ID：{{logDetail.id}}</div>
          <div style="margin-top: 10px">日志类型：{{logType}}</div>
          <div style="margin-top: 10px">发送方IP：{{logDetail.uploadIp}}</div>
          <div style="margin-top: 10px">上传用户：{{logDetail.createUser}}</div>
          <div style="margin-top: 10px">数字摘要：{{logDetail.fileHash}}</div>
        </div></el-col>
        <el-col :span="12"><div>
          <div>群组：{{logDetail.groupId}}</div>
          <div style="margin-top: 10px">是否漂白：{{logDetail.bleach}}</div>
          <div style="margin-top: 10px">是否隐藏：{{logDetail.hide}}</div>
          <div style="margin-top: 10px">是否脱敏：{{logDetail.desensitization}}</div>
          <div style="margin-top: 10px">上传时间：{{logDetail.createTime}}</div>
        </div></el-col>
      </el-row>
    </el-card>
        <el-table ref="contentTable"
                style="width: 100%"
                v-el-table-infinite-scroll="load"
                :data="shardContent"
                :infinite-scroll-disabled="disabled"
                height="500px" border>
        <el-table-column label="日志内容">
          <template slot-scope="scope">{{scope.row.content}}</template>
        </el-table-column>
      </el-table>
      <span slot="footer" class="dialog-footer">
        <el-button type="primary" @click="dialogVisible = false" size="small">确 定</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
  import { findLogByStatus, getLogInfo, getFileContentShard } from '@/api/log'
  import ElTableInfiniteScroll from "el-table-infinite-scroll"

  const defaultLogDetail = {
    "fileID": "",
    "logType": "",
    "fileHash": "", //文件哈希
    "sourceIP": "",
    "userID": "",
    "uploadTime": "",
    "isBleach": false, //是否漂白
    "isHide": false, //是否隐藏
    "isSensitive": false, //是否脱敏
    "groupID": "",
    "fileContent": [], //日志内容列表
  }

  export default {
    name: "logList",
    directives: {
      "el-table-infinite-scroll": ElTableInfiniteScroll,
    },
    data() {
      return {
        list: null,
        logDetail: Object.assign({}, defaultLogDetail),
        total: null,
        listLoading: true,
        dialogVisible: false,
        listQuery: {
          current: 1,
          size: 5,
          status: 0
        },
        shardQuery: {
          fileId: null,
          shardIndex: 0
        },
        shardContent: [{
          content: ''
        }],
        disabled: false
      }
    },
    created() {
      this.getList();
    },
    computed: {
      logType() {
        if (this.logDetail.logType === '5') {
          return 'syslog'
        }
        if (this.logDetail.logType === '6') {
          return 'kafka'
        }
        if (this.logDetail.logType === '7') {
          return 'hadoop'
        }
      }
    },
    methods: {
      typeFormat(row, column) {
        if(row.type === 1) {
          return '安全日志'
        }
        if(row.type === 2) {
          return '流量日志'
        }
        if(row.type === 3) {
          return '系统日志'
        }
      },
      load() {
        if (this.disabled) return;
        this.shardQuery.shardIndex++;
        getFileContentShard(this.shardQuery).then(res => {
          if(res.data === null) {
            this.disabled = true;
          } else {
            this.shardContent[0].content += res.data
          }
        })
        console.log(this.shardQuery.shardIndex)
      },
      handleAddLog() {
        this.$router.push('/log/addLog');
      },
      getList() {
        this.listLoading = true;
        findLogByStatus(this.listQuery).then(res => {
          console.log(res);
          this.listLoading = false;
          this.list = res.data.records;
          this.total = parseInt(res.data.total);
        })
      },
      handleSizeChange(val) {
        this.listQuery.current = 1;
        this.listQuery.size = val;
        this.getList();
      },
      handleCurrentChange(val) {
        this.listQuery.current = val;
        this.getList();
      },
      handleDetail(index, row) {
        console.log(index, )
        getLogInfo({id: row.id}).then(res => {
          console.log(res);
          this.logDetail = res.data;
          this.shardQuery.fileId = res.data.fileId;
          this.shardQuery.shardIndex = 0;
          getFileContentShard(this.shardQuery).then(res => {
            console.log(res.data);
            this.shardContent[0].content = res.data
            console.log(this.shardContent)
          })
          this.dialogVisible = true;
          this.disabled = false;
        })
      },
      handleCheck(index, row) {
        this.$confirm('是否进行一致性校验？', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          deleteProductCate(row.id).then(response => {
            this.$message({
              message: '校验成功',
              type: 'success',
              duration: 1000
            });
          });
        });
      }
    }
  }
</script>

<style lang="scss" scoped>
 
  </style>
