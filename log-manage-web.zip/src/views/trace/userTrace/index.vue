<template> 
    <div class="app-container">
      <!-- <el-card class="filter-container" shadow="never">
        <div>
          <i class="el-icon-search"></i>
          <span>筛选搜索</span>
          <el-button
            style="float:right"
            type="primary"
            @click="handleSearchList()"
            size="small">
            查询搜索
          </el-button>
          <el-button
            style="float:right;margin-right: 15px"
            @click="handleResetSearch()"
            size="small">
            重置
          </el-button>
        </div>
        <div style="margin-top: 15px">
          <el-form :inline="true" :model="listQuery" size="small" label-width="140px">
            <el-form-item label="输入搜索：">
              <el-input v-model="listQuery.keyword" class="input-width" placeholder="帐号/姓名" clearable></el-input>
            </el-form-item>
          </el-form>
        </div>
      </el-card> -->
      <!-- <el-card class="operate-container" shadow="never">
        <i class="el-icon-tickets"></i>
        <span>用户列表</span>
        <el-button size="mini" class="btn-add" @click="handleAdd()" style="margin-left: 20px">添加</el-button>
      </el-card> -->
      <div class="table-container">
      <el-table ref="userTable"
                :data="list"
                style="width: 100%;"
                v-loading="listLoading" border>
        <el-table-column label="用户ID" align="center">
          <template slot-scope="scope">{{scope.row.id}}</template>
        </el-table-column>
        <el-table-column label="用户名" align="center">
          <template slot-scope="scope">{{scope.row.username}}</template>
        </el-table-column>
        <el-table-column label="用户地址" align="center">
          <template slot-scope="scope">{{scope.row.address}}</template>
        </el-table-column>
        <el-table-column label="群组" align="center">
          <template slot-scope="scope">{{scope.row.groupId}}</template>
        </el-table-column>
        <el-table-column label="操作" width="180" align="center">
          <template slot-scope="scope">
            <el-button size="mini"
                       type="primary"
                       @click="handleUserTrace(scope.$index, scope.row)">
              溯源
            </el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <div class="pagination-container">
      <el-pagination
        background
        layout="total, sizes,prev, pager, next,jumper"
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
        :current-page.sync="listQuery.current"
        :page-size="listQuery.size"
        :page-sizes="[10,15,20]"
        :total="total">
      </el-pagination>
    </div>
      <el-dialog
        title='溯源结果'
        :visible.sync="dialogVisible"
        width="40%">
        <div class="table-container">
      <el-table ref="opLogTable"
                :data="listTrace"
                style="width: 100%;"
                max-height="500"
                v-loading="listTraceLoading" border>
        <el-table-column label="操作类型" align="center" :formatter="opTypeFormat">
          <!-- <template slot-scope="scope">{{scope.row.opLogType}}</template> -->
        </el-table-column>
        <el-table-column label="操作日志" align="center">
          <template slot-scope="scope">{{scope.row.targetId}}</template>
        </el-table-column>
        <el-table-column label="日志类型" align="center" :formatter="logTypeFormat">
          <!-- <template slot-scope="scope">{{scope.row.logType}}</template> -->
        </el-table-column>
        <el-table-column label="操作时间" align="center">
          <template slot-scope="scope">{{scope.row.createTime}}</template>
        </el-table-column>
        <el-table-column label="操作" align="center">
          <template slot-scope="scope">
            <el-button type="primary" @click="handleDetail(scope.$index, scope.row)" size="small">数据锚定</el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <div class="pagination-container">
      <el-pagination
        background
        @size-change="handleTraceSizeChange"
        @current-change="handleTraceCurrentChange"
        layout="total, sizes,prev, pager, next,jumper"
        :current-page.sync="listTraceQuery.current"
        :page-size="listTraceQuery.size"
        :page-sizes="[10,15,20]"
        :total="total">
      </el-pagination>
    </div>
        <span slot="footer" class="dialog-footer">
        </span>
      </el-dialog>
      <el-dialog
      title="数据锚定"
      :visible.sync="detailVisible"
      width="40%">
      <el-card>
          <div style="margin-top: 10px">文件ID：{{logDetail.id}}</div>
          <div style="margin-top: 10px">发送方IP：{{logDetail.srcIp}}</div>
          <div style="margin-top: 10px">数字摘要：{{logDetail.hashcode}}</div>
    </el-card>
        <el-table ref="contentTable"
                style="width: 100%"
                v-el-table-infinite-scroll="load"
                :data="shardContent"
                :infinite-scroll-disabled="disabled"
                height="500px" border>
        <el-table-column label="文件内容">
          <template slot-scope="scope">{{scope.row.content}}</template>
        </el-table-column>
      </el-table>
      <span slot="footer" class="dialog-footer">
        <el-button type="primary" @click="detailVisible = false; disabled = false" size="small">确 定</el-button>
      </span>
    </el-dialog>
    </div>
  </template>
  <script>
    import { listPage } from '@/api/user'
    import { listOpLog } from '@/api/trace'
    import { getFileInfo, getFileContentShard } from '@/api/log'
    import ElTableInfiniteScroll from "el-table-infinite-scroll"
  
    const defaultListQuery = {
      current: 1,
      size: 10
    };
    const defaultListTraceQuery = {
      current: 1,
      size: 10,
      username: null
    };
    const defaultLogDetail = {
      "id": '',
      "srcIp": '',
      "hashcode": ''
    };
    export default {
      name: 'userTrace',
      directives: {
        "el-table-infinite-scroll": ElTableInfiniteScroll,
      },
      data() {
        return {
          listQuery: Object.assign({}, defaultListQuery),
          listTraceQuery: Object.assign({}, defaultListTraceQuery),
          list: null,
          listTrace: null,
					opLogList: null,
          total: null,
          logDetail: Object.assign({}, defaultLogDetail),
          listLoading: false,
          listTraceLoading: false,
          dialogVisible: false,
          detailVisible: false,
          shardQuery: {
            fileId: null,
            shardIndex: 0
          },
          shardContent: [{
            content: ''
          }],
          disabled: false
          }
      },
      created() {
        this.getList();
      },
      methods: {
        opTypeFormat(row, column) {
        if(row.opLogType === 1) {
          return '上传日志'
        }
        if(row.opLogType === 2) {
          return '查看详情'
        }
      },
      logTypeFormat(row, column) {
        if(row.logType === 5){
          return 'syslog'
        }
        if(row.logType === 6){
          return 'kafka'
        }
        if(row.logType === 7){
          return 'hadoop'
        }
      },
        load() {
          if (this.disabled) return;
          this.shardQuery.shardIndex++;
          getFileContentShard(this.shardQuery).then(res => {
            if(res.data === null) {
              this.disabled = true;
            } else {
              this.shardContent[0].content += res.data
            }
          })
          console.log(this.shardQuery.shardIndex)
        },
        handleDetail(index, row) {
          console.log(row)
          console.log(this.disabled)
          getFileInfo(row.targetId).then(res => {
            console.log(res);
            this.logDetail = res.data;
            this.shardQuery.fileId = row.targetId;
            this.shardQuery.shardIndex = 0;
            getFileContentShard(this.shardQuery).then(res => {
              console.log(res.data);
              this.shardContent[0].content = res.data
              console.log(this.shardContent)
            })
            this.detailVisible = true;
            this.disabled = false;
          })
        },
        handleTraceSizeChange(val) {
          this.listTraceQuery.current = 1;
          this.listTraceQuery.size = val;
          this.getTraceList();
        },
        handleTraceCurrentChange(val) {
          this.listTraceQuery.current = val;
          this.getTraceList();
        },
        handleSizeChange(val) {
          this.listQuery.current = 1;
          this.listQuery.size = val;
          this.getList();
        },
        handleCurrentChange(val) {
          this.listQuery.current = val;
          this.getList();
        },
        handleUserTrace(index, row) {
          this.dialogVisible = true;
					this.listTraceQuery.username = row.username;
          this.getTraceList();
        },
        getList() {
          this.listLoading = true;
          listPage(this.listQuery).then(res => {
            console.log(res.data);
            this.listLoading = false;
            this.list = res.data.records;
            this.total = parseInt(res.data.total);
          })
        },
        getTraceList() {
          this.listTraceLoading = true;
          console.log(this.listTraceQuery)
          listOpLog(this.listTraceQuery).then(res => {
            console.log(res.data);
            this.listTraceLoading = false;
            this.listTrace = res.data.records;
            this.total = parseInt(res.data.total);
          })
        }
      }
    }
  </script>
  <style></style>
  
  
  