<template> 
  <div class="app-container">
    <div class="table-container">
      <el-table ref="logListTable"
                style="width: 100%"
                :data="list"
                v-loading="listLoading" border>
        <el-table-column label="日志ID" align="center">
          <template slot-scope="scope">{{scope.row.id}}</template>
        </el-table-column>
        <el-table-column label="数字摘要" align="center">
          <template slot-scope="scope">{{scope.row.hash}}</template>
        </el-table-column>
        <el-table-column label="上传时间" align="center">
          <template slot-scope="scope">{{scope.row.createTime}}</template>
        </el-table-column>
        <el-table-column label="日志类型" align="center" :formatter="typeFormat">
          <!-- <template slot-scope="scope">{{scope.row.type }}</template> -->
        </el-table-column>
        <el-table-column label="操作" align="center">
          <template slot-scope="scope">
            <el-button
              size="mini"
              type="primary"
              @click="handleLogTrace(scope.$index, scope.row)">溯源
            </el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <div class="pagination-container">
      <el-pagination
        background
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
        layout="total, sizes,prev, pager, next,jumper"
        :page-size="listQuery.size"
        :page-sizes="[5,10,15]"
        :current-page.sync="listQuery.current"
        :total="total">
      </el-pagination>
    </div>
    <el-dialog
      title='溯源结果'
      :visible.sync="dialogVisible"
      width="40%">
      <div class="table-container">
      <el-table ref="opLogTable"
                :data="listTrace"
                style="width: 100%;"
                max-height="500"
                v-loading="listTraceLoading" border>
        <el-table-column label="用户" align="center">
          <template slot-scope="scope">{{scope.row.createUser}}</template>
        </el-table-column>
        <el-table-column label="操作类型" align="center" :formatter="opTypeFormat">
          <!-- <template slot-scope="scope">{{scope.row.opLogType}}</template> -->
        </el-table-column>
        <el-table-column label="操作时间" align="center">
          <template slot-scope="scope">{{scope.row.createTime}}</template>
        </el-table-column>
      </el-table>
    </div>
    <div class="pagination-container">
      <el-pagination
        background
        @size-change="handleTraceSizeChange"
        @current-change="handleTraceCurrentChange"
        layout="total, sizes,prev, pager, next,jumper"
        :current-page.sync="listTraceQuery.current"
        :page-size="listTraceQuery.size"
        :page-sizes="[10,15,20]"
        :total="total">
      </el-pagination>
    </div>
      <span slot="footer" class="dialog-footer">
        <el-button size="small" type="primary" @click="handleDetail">数据锚定</el-button>
        <el-button size="small" type="success">可视化</el-button>
      </span>
    </el-dialog>
    <el-dialog
      title="数据锚定"
      :visible.sync="detailVisible"
      width="40%">
      <el-card>
          <div style="margin-top: 10px">文件ID：{{logDetail.id}}</div>
          <div style="margin-top: 10px">发送方IP：{{logDetail.srcIp}}</div>
          <div style="margin-top: 10px">数字摘要：{{logDetail.hashcode}}</div>
    </el-card>
        <el-table ref="contentTable"
                style="width: 100%"
                v-el-table-infinite-scroll="load"
                :data="shardContent"
                :infinite-scroll-disabled="disabled"
                height="500px" border>
        <el-table-column label="文件内容">
          <template slot-scope="scope">{{scope.row.content}}</template>
        </el-table-column>
      </el-table>
      <span slot="footer" class="dialog-footer">
        <el-button type="primary" @click="detailVisible = false" size="small">确 定</el-button>
      </span>
    </el-dialog>
  </div>
</template>
<script>
  import { findLogByStatus } from '@/api/log'
  import { listOpLog } from '@/api/trace'
  import { getFileInfo, getFileContentShard } from '@/api/log'
  import ElTableInfiniteScroll from "el-table-infinite-scroll"

  const defaultListQuery = {
    current: 1,
    size: 5,
    status: 0
  };
  const defaultLogDetail = {
    "id": '',
    "srcIp": '',
    "hashcode": ''
  };

  const defaultListTraceQuery = {
    current: 1,
    size: 10,
    targetId: null
  };
  export default {
    name: 'logTrace',
    directives: {
      "el-table-infinite-scroll": ElTableInfiniteScroll,
    },
    data() {
      return {
        listQuery: Object.assign({}, defaultListQuery),
        listTraceQuery: Object.assign({}, defaultListTraceQuery),
        list: null,
        listTrace: null,
        total: null,
        logDetail: Object.assign({}, defaultLogDetail),
        listLoading: false,
        listTraceLoading: false,
        dialogVisible: false,
        detailVisible: false,
        shardQuery: {
          fileId: null,
          shardIndex: 0
        },
        shardContent: [{
          content: ''
        }],
        disabled: false
      }
    },
    created() {
      this.getList();
    },
    methods: {
      opTypeFormat(row, column) {
        if(row.opLogType === 1) {
          return '上传日志'
        }
        if(row.opLogType === 2) {
          return '查看详情'
        }
      },
      typeFormat(row, column) {
        if(row.type === 1) {
          return '安全日志'
        }
        if(row.type === 2) {
          return '流量日志'
        }
        if(row.type === 3) {
          return '系统日志'
        }
      },
      load() {
        if (this.disabled) return;
        this.shardQuery.shardIndex++;
        getFileContentShard(this.shardQuery).then(res => {
          if(res.data === null) {
            this.disabled = true;
          } else {
            this.shardContent[0].content += res.data
          }
        })
        console.log(this.shardQuery.shardIndex)
      },
      handleDetail() {
        getFileInfo(this.shardQuery.fileId).then(res => {
          console.log(res);
          this.logDetail = res.data;
          // this.shardQuery.fileId = row.targetId;
          this.shardQuery.shardIndex = 0;
          getFileContentShard(this.shardQuery).then(res => {
            console.log(res.data);
            this.shardContent[0].content = res.data
            console.log(this.shardContent)
          })
          this.detailVisible = true;
          this.disabled = false;
        })
      },
      handleTraceSizeChange(val) {
        this.listTraceQuery.current = 1;
        this.listTraceQuery.size = val;
        this.getTraceList();
      },
      handleTraceCurrentChange(val) {
        this.listTraceQuery.current = val;
        this.getTraceList();
      },
      handleSizeChange(val) {
        this.listQuery.current = 1;
        this.listQuery.size = val;
        this.getList();
      },
      handleCurrentChange(val) {
        this.listQuery.current = val;
        this.getList();
      },
      handleLogTrace(index, row) {
        this.dialogVisible = true;
        console.log(row)
        this.listTraceQuery.targetId = row.logFileId;
        this.shardQuery.fileId = row.logFileId;
        this.getTraceList();
      },
      getList() {
        this.listLoading = true;
        findLogByStatus(this.listQuery).then(res => {
          console.log(res);
          this.listLoading = false;
          this.list = res.data.records;
          this.total = parseInt(res.data.total);
        })
      },
      getTraceList() {
        this.listTraceLoading = true;
        listOpLog(this.listTraceQuery).then(res => {
          console.log(res.data);
          this.listTraceLoading = false;
          this.listTrace = res.data.records;
          this.total = parseInt(res.data.total);
        })
      }
    }
  }
</script>
<style></style>
